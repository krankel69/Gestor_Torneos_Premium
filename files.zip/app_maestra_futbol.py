# app_maestra_futbol.py  —  El Director de Orquesta
# Fase 1 + Fase 2 del plan Premium: modular + lobby dinamico.
import sys
import os
import csv
import json
import sqlite3
import traceback
from datetime import datetime
from collections import Counter

# --- CHIVATO DE ERRORES ---
try:
    chivato = open("log_errores.txt", "w", encoding="utf-8")
    sys.stdout = chivato
    sys.stderr = chivato
    print("Iniciando Aplicacion Maestra...")
except Exception:
    pass

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
import ttkbootstrap as tb
from ttkbootstrap.constants import *

# Modulos propios (Fase 1)
from database import GestorBaseDeDatos
from ui_components import AutocompleteCombobox, VentanaGoleadores

try:
    import sincronizador
    HAS_SINCRONIZADOR = True
except ImportError:
    HAS_SINCRONIZADOR = False

try:
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
    HAS_REPORTLAB = True
except ImportError:
    HAS_REPORTLAB = False


# ===================================================================
# MODELOS DE DATOS
# ===================================================================

class Equipo:
    def __init__(self, id_equipo, nombre, ciudad, pj=0, pg=0, pe=0, pp=0, gf=0, gc=0, pts=0):
        self.id = id_equipo
        self.nombre = nombre
        self.ciudad = ciudad
        self.estadisticas = {"pj": pj, "pg": pg, "pe": pe, "pp": pp, "gf": gf, "gc": gc, "puntos": pts}
        self.jugadores = []


class Jugador:
    def __init__(self, id_jugador, nombre, equipo_id, goles_marcados=0):
        self.id = id_jugador
        self.nombre = nombre
        self.equipo_id = equipo_id
        self.goles_marcados = goles_marcados


class Partido:
    def __init__(self, id_partido, equipo_local_id, equipo_visitante_id, fecha, goles_local=-1, goles_visitante=-1, jugado=0, archivado=0):
        self.id = id_partido
        self.equipo_local_id = equipo_local_id
        self.equipo_visitante_id = equipo_visitante_id
        self.fecha = fecha
        self.goles_local = goles_local
        self.goles_visitante = goles_visitante
        self.jugado = jugado
        self.archivado = archivado
        self.marcador = {"local": max(0, goles_local), "visitante": max(0, goles_visitante)}
        self.resultado = f"{goles_local}-{goles_visitante}" if jugado else None


# ===================================================================
# GESTOR DE BASE DE DATOS (ESQUEMA UNIFICADO DE LIGA_FUTBOL.DB)
# ===================================================================



class AppLigaFutbol(tb.Window):
    def __init__(self, db_path, themename="litera"):
        super().__init__(themename=themename, title="Gestión de Liga de Fútbol - Aplicación Maestra")
        self.geometry("1250x850")
        self.withdraw()  # Oculta hasta que todo cargue
        self.protocol("WM_DELETE_WINDOW", self.al_cerrar)

        if HAS_SINCRONIZADOR:
            try:
                print("Sincronizando bases de datos al inicio...")
                sincronizador.ejecutar_sincronizacion()
            except Exception as e:
                print(f"Aviso: Error en sincronización inicial: {e}")

        self.db = GestorBaseDeDatos(db_path)
        self.mostrar_archivados_var = tk.BooleanVar(value=False)
        self._crear_ui()
        self._refresh_all()
        self.deiconify()  # Muestra la ventana cuando todo esta listo

    def _crear_ui(self):
        # Menú Superior
        menu_bar = tk.Menu(self)
        menu_admin = tk.Menu(menu_bar, tearoff=0)
        menu_admin.add_command(label="🔄 Importar Goleadores (Sustituir)", command=self.importar_goleadores_sustituyendo)
        menu_admin.add_command(label="🔍 Simulacro Historial", command=self._on_simulacro_historial)
        menu_admin.add_command(label="♻️ Nueva Temporada (Reset Total)", command=self._on_nueva_temporada)
        menu_bar.add_cascade(label="⚙️ ADMIN", menu=menu_admin)
        self.config(menu=menu_bar)

        self.notebook = tb.Notebook(self)
        self.notebook.pack(fill=BOTH, expand=True, padx=10, pady=10)

        # --- PESTAÑA LIGA (Contenedor Principal) ---
        self.tab_liga = tb.Notebook(self.notebook)
        self.notebook.add(self.tab_liga, text="🇪🇸 Liga KranKel")

        # Sub-pestañas de la Liga
        self.sub_tab_clasificacion = tb.Frame(self.tab_liga)
        self.tab_liga.add(self.sub_tab_clasificacion, text="📊 Clasificación")

        self.sub_tab_jugadores = tb.Frame(self.tab_liga)
        self.tab_liga.add(self.sub_tab_jugadores, text="🏃 Jugadores")

        self.sub_tab_partidos = tb.Frame(self.tab_liga)
        self.tab_liga.add(self.sub_tab_partidos, text="⚽ Partidos")

        self.sub_tab_goleadores = tb.Frame(self.tab_liga)
        self.tab_liga.add(self.sub_tab_goleadores, text="🏆 Goleadores")

        self.sub_tab_exportar = tb.Frame(self.tab_liga)
        self.tab_liga.add(self.sub_tab_exportar, text="📄 Exportar")

        # Inyectamos las funciones SOLO UNA VEZ en su lugar correspondiente
        self._ui_equipos(self.sub_tab_clasificacion)
        self._ui_jugadores(self.sub_tab_jugadores)
        self._ui_partidos(self.sub_tab_partidos)
        self._ui_goleadores(self.sub_tab_goleadores)
        self._ui_exportar(self.sub_tab_exportar)

        # --- PESTAÑA MUNDIAL (Aislada con Sub-pestañas) ---
        self.tab_mundial_base = tb.Notebook(self.notebook)
        self.notebook.add(self.tab_mundial_base, text="🌍 Mundial 2026")

        self.sub_tab_mundial_grupos = tb.Frame(self.tab_mundial_base)
        self.tab_mundial_base.add(self.sub_tab_mundial_grupos, text="📋 Fase de Grupos y Partidos")
        self._ui_mundial(self.sub_tab_mundial_grupos)

        self.sub_tab_mundial_eliminatorias = tb.Frame(self.tab_mundial_base)
        self.tab_mundial_base.add(self.sub_tab_mundial_eliminatorias, text="🏆 Configuración de Eliminatorias")
        self._ui_mundial_eliminatorias(self.sub_tab_mundial_eliminatorias)

        btn_salir = tb.Button(self, text="Salir 🚪", command=self.al_cerrar, bootstyle=DANGER)
        btn_salir.pack(pady=10, padx=10, side=BOTTOM, fill=X)

    def _ui_equipos(self, parent):
        # Ya no creamos el 'tab' aquí, usamos 'parent' directamente
        frm_izq = tb.Frame(parent, padding=10)
        frm_izq.pack(side=LEFT, fill=Y, ipadx=10, anchor="n")

        frm_der = tb.Frame(parent, padding=10)
        frm_der.pack(side=RIGHT, fill=BOTH, expand=True)

        # Controles Izquierda
        tb.Label(frm_izq, text="Añadir Equipo", font="-size 12 -weight bold").pack(pady=10, anchor=W)
        tb.Label(frm_izq, text="Nombre del Equipo:").pack(anchor=W)
        self.entry_equipo_nombre = tb.Entry(frm_izq, width=30)
        self.entry_equipo_nombre.pack(fill=X, pady=2)
        tb.Label(frm_izq, text="Ciudad:").pack(anchor=W)
        self.entry_equipo_ciudad = tb.Entry(frm_izq, width=30)
        self.entry_equipo_ciudad.pack(fill=X, pady=2)
        tb.Button(frm_izq, text="➕ Añadir Equipo", command=self._on_aniadir_equipo, bootstyle=SUCCESS).pack(pady=10, fill=X)

        tb.Separator(frm_izq, orient=HORIZONTAL).pack(fill=X, pady=15)
        tb.Button(frm_izq, text="📁 Importar Equipos (CSV)", command=self._on_cargar_equipos_csv, bootstyle=INFO).pack(fill=X, pady=5)

        tb.Separator(frm_izq, orient=HORIZONTAL).pack(fill=X, pady=15)
        tb.Label(frm_izq, text="Eliminar Equipo:").pack(anchor=W)
        self.combo_equipos_del = AutocompleteCombobox(frm_izq, width=28)
        self.combo_equipos_del.pack(fill=X, pady=5)
        tb.Button(frm_izq, text="🗑️ Eliminar Equipo", command=self._on_eliminar_equipo, bootstyle=DANGER).pack(fill=X, pady=5)

        # Edición Manual de Clasificación
        tb.Separator(frm_izq, orient=HORIZONTAL).pack(fill=X, pady=15)
        tb.Label(frm_izq, text="Ajuste Manual Puntos", font="-size 10 -weight bold").pack(anchor=W)
        self.combo_equipos_manual_pts = AutocompleteCombobox(frm_izq, width=28)
        self.combo_equipos_manual_pts.pack(fill=X, pady=2)

        frm_grid_stats = tb.Frame(frm_izq)
        frm_grid_stats.pack(fill=X, pady=5)
        tb.Label(frm_grid_stats, text="PJ:").grid(row=0, column=0, sticky=W)
        self.entry_m_pj = tb.Entry(frm_grid_stats, width=5)
        self.entry_m_pj.grid(row=0, column=1, padx=2)
        tb.Label(frm_grid_stats, text="PG:").grid(row=0, column=2, sticky=W)
        self.entry_m_pg = tb.Entry(frm_grid_stats, width=5)
        self.entry_m_pg.grid(row=0, column=3, padx=2)
        tb.Label(frm_grid_stats, text="PTS:").grid(row=0, column=4, sticky=W)
        self.entry_m_pts = tb.Entry(frm_grid_stats, width=5)
        self.entry_m_pts.grid(row=0, column=5, padx=2)

        tb.Button(frm_izq, text="💾 Guardar Ajuste", command=self._on_guardar_clasificacion_manual, bootstyle=PRIMARY).pack(fill=X, pady=5)
        tb.Button(frm_izq, text="🔄 Recalcular Todo", command=self._on_recalcular_clasificacion, bootstyle=SECONDARY).pack(fill=X, pady=2)

        # Tabla de Posiciones Derecha
        tb.Label(frm_der, text="Tabla de Posiciones", font="-size 13 -weight bold").pack(pady=5, anchor=W)
        columnas = ("pos", "equipo", "pj", "pg", "pe", "pp", "gf", "gc", "pts", "estado")
        self.tree_clasificacion = tb.Treeview(frm_der, columns=columnas, show="headings", height=22)

        for col in columnas:
            self.tree_clasificacion.heading(col, text=col.upper())

        self.tree_clasificacion.column("pos", width=40, anchor="center")
        self.tree_clasificacion.column("equipo", width=180)
        for col in ("pj", "pg", "pe", "pp", "gf", "gc", "pts"):
            self.tree_clasificacion.column(col, width=45, anchor="center")
        self.tree_clasificacion.column("estado", width=120, anchor="center")
        self.tree_clasificacion.pack(fill=BOTH, expand=True, pady=5)

        # Tags (se mantienen igual)
        self.tree_clasificacion.tag_configure("campeon", background="#006400", foreground="white", font=("Segoe UI", 9, "bold"))
        self.tree_clasificacion.tag_configure("lider", background="#228B22", foreground="white", font=("Segoe UI", 9, "bold"))
        self.tree_clasificacion.tag_configure("champions", background="#90EE90", foreground="#000000")
        self.tree_clasificacion.tag_configure("eurleague", background="#ADD8E6", foreground="#000000")
        self.tree_clasificacion.tag_configure("confleague", background="#D8BFD8", foreground="#000000")
        self.tree_clasificacion.tag_configure("descenso", background="#CD5C5C", foreground="white")

    def _ui_jugadores(self, parent):
        # Usamos 'parent' (la pestaña) directamente
        frm_controles = tb.Frame(parent, padding=10)
        frm_controles.pack(side=LEFT, fill=Y, ipadx=10, anchor="n")

        frm_tabla = tb.Frame(parent, padding=10)
        frm_tabla.pack(side=RIGHT, fill=BOTH, expand=True)

        # Controles
        tb.Label(frm_controles, text="Gestión Individual", font="-size 12 -weight bold").pack(pady=10, anchor=W)
        tb.Label(frm_controles, text="Equipo Asociado:").pack(anchor=W)
        self.combo_jugadores_equipo = AutocompleteCombobox(frm_controles, width=28)
        self.combo_jugadores_equipo.pack(fill=X, pady=2)
        tb.Label(frm_controles, text="Nombre Jugador:").pack(anchor=W)
        self.entry_jugador_nombre = tb.Entry(frm_controles, width=30)
        self.entry_jugador_nombre.pack(fill=X, pady=2)
        tb.Button(frm_controles, text="➕ Añadir Jugador", command=self._on_aniadir_jugador, bootstyle=SUCCESS).pack(pady=10, fill=X)

        tb.Separator(frm_controles, orient=HORIZONTAL).pack(fill=X, pady=15)
        tb.Button(frm_controles, text="📂 Cargar desde Carpeta CSV", command=self._on_cargar_jugadores_carpeta, bootstyle=INFO).pack(fill=X, pady=5)

        tb.Separator(frm_controles, orient=HORIZONTAL).pack(fill=X, pady=15)
        tb.Label(frm_controles, text="Eliminar Jugador:").pack(anchor=W)
        self.entry_jugador_del = tb.Entry(frm_controles, width=30)
        self.entry_jugador_del.pack(fill=X, pady=2)
        tb.Button(frm_controles, text="🗑️ Eliminar por Nombre", command=self._on_eliminar_jugador, bootstyle=DANGER).pack(fill=X, pady=5)

        # Tabla
        tb.Label(frm_tabla, text="Lista Global de Jugadores Registrados", font="-size 13 -weight bold").pack(pady=5, anchor=W)
        self.tree_jugadores = tb.Treeview(frm_tabla, columns=("id", "nombre", "equipo", "goles"), show="headings", height=22)
        self.tree_jugadores.heading("id", text="ID")
        self.tree_jugadores.heading("nombre", text="Nombre")
        self.tree_jugadores.heading("equipo", text="Equipo")
        self.tree_jugadores.heading("goles", text="Goles Totales")
        self.tree_jugadores.column("id", width=60, anchor="center")
        self.tree_jugadores.column("goles", width=100, anchor="center")
        self.tree_jugadores.pack(fill=BOTH, expand=True, pady=5)

    def _ui_partidos(self, parent):
        # Eliminamos la creación del tab y usamos parent directamente
        frm_top = tb.Frame(parent, padding=5)
        frm_top.pack(fill=X, side=TOP)

        frm_controles = tb.Frame(parent, padding=10)
        frm_controles.pack(side=LEFT, fill=Y, ipadx=10, anchor="n")

        frm_tabla = tb.Frame(parent, padding=10)
        frm_tabla.pack(side=RIGHT, fill=BOTH, expand=True)

        # Filtro de Jornada Superior
        tb.Label(frm_top, text="Seleccionar Fecha/Jornada:", font="-weight bold").pack(side=LEFT, padx=10)
        self.combo_filtra_jornadas = AutocompleteCombobox(frm_top, width=25)
        self.combo_filtra_jornadas.pack(side=LEFT, padx=5)
        self.combo_filtra_jornadas.bind("<<ComboboxSelected>>", self._on_jornada_filtrada)

        tb.Checkbutton(frm_top, text="Ver partidos archivados", variable=self.mostrar_archivados_var, command=self._on_jornada_filtrada).pack(side=LEFT, padx=20)

        # Controles Programación Izquierda
        tb.Label(frm_controles, text="Programar Partido", font="-size 12 -weight bold").pack(pady=10, anchor=W)
        tb.Label(frm_controles, text="Equipo Local:").pack(anchor=W)
        self.combo_partido_local = AutocompleteCombobox(frm_controles, width=28)
        self.combo_partido_local.pack(fill=X, pady=2)
        tb.Label(frm_controles, text="Equipo Visitante:").pack(anchor=W)
        self.combo_partido_visitante = AutocompleteCombobox(frm_controles, width=28)
        self.combo_partido_visitante.pack(fill=X, pady=2)
        tb.Label(frm_controles, text="Fecha (AAAA-MM-DD):").pack(anchor=W)
        self.entry_partido_fecha = tb.Entry(frm_controles, width=30)
        self.entry_partido_fecha.pack(fill=X, pady=2)
        self.entry_partido_fecha.insert(0, datetime.now().strftime("%Y-%m-%d"))
        tb.Button(frm_controles, text="🗓️ Programar Partido", command=self._on_crear_partido, bootstyle=SUCCESS).pack(pady=10, fill=X)

        tb.Separator(frm_controles, orient=HORIZONTAL).pack(fill=X, pady=10)
        tb.Button(frm_controles, text="📁 Importar Jornada (CSV)", command=self._on_cargar_jornada_csv, bootstyle=INFO).pack(fill=X, pady=5)

        tb.Separator(frm_controles, orient=HORIZONTAL).pack(fill=X, pady=10)
        tb.Label(frm_controles, text="Registrar Resultado Directo:").pack(anchor=W)
        tb.Label(frm_controles, text="Goles Local / Visitante:").pack(anchor=W)
        frm_goles_row = tb.Frame(frm_controles)
        frm_goles_row.pack(fill=X, pady=2)
        self.entry_goles_l = tb.Entry(frm_goles_row, width=8)
        self.entry_goles_l.pack(side=LEFT, padx=2)
        self.entry_goles_v = tb.Entry(frm_goles_row, width=8)
        self.entry_goles_v.pack(side=LEFT, padx=2)
        tb.Button(frm_controles, text="✅ Grabar Marcador", command=self._on_registrar_resultado, bootstyle=SUCCESS).pack(fill=X, pady=5)

        tb.Separator(frm_controles, orient=HORIZONTAL).pack(fill=X, pady=10)
        self.btn_archivar_partido = tb.Button(frm_controles, text="🗄️ Archivar Partido", command=self._on_toggle_archivo_partido, bootstyle=SECONDARY)
        self.btn_archivar_partido.pack(fill=X, pady=2)
        tb.Button(frm_controles, text="❌ Eliminar Partido", command=self._on_eliminar_partido, bootstyle=DANGER).pack(fill=X, pady=2)

        # Tablas Resultados y Goleadores del Partido
        tb.Label(frm_tabla, text="Partidos de la Jornada Seleccionada (Doble clic para goleadores)", font="-size 11").pack(pady=2, anchor=W)
        columnas_p = ("id", "local", "visitante", "gl", "gv", "fecha")
        self.tree_partidos = tb.Treeview(frm_tabla, columns=columnas_p, show="headings", height=12)
        for col in columnas_p:
            self.tree_partidos.heading(col, text=col.upper())
        self.tree_partidos.column("id", width=50, anchor="center")
        self.tree_partidos.column("gl", width=60, anchor="center")
        self.tree_partidos.column("gv", width=60, anchor="center")
        self.tree_partidos.pack(fill=X, pady=5)
        self.tree_partidos.bind("<Double-1>", self._on_partido_doble_clic)
        self.tree_partidos.bind("<<TreeviewSelect>>", self._on_partido_seleccionado_ver_goleadores)

        tb.Label(frm_tabla, text="Desglose de Goleadores del Partido Seleccionado", font="-weight bold").pack(pady=5, anchor=W)
        self.tree_goleadores_partido = tb.Treeview(frm_tabla, columns=("jugador", "goles"), show="headings", height=5)
        self.tree_goleadores_partido.heading("jugador", text="Jugador")
        self.tree_goleadores_partido.heading("goles", text="Goles En el Partido")
        self.tree_goleadores_partido.column("goles", width=150, anchor="center")
        self.tree_goleadores_partido.pack(fill=BOTH, expand=True)

    def _ui_goleadores(self, parent):
        # Usamos 'parent' directamente en lugar de crear un tab nuevo
        frm_top = tb.Frame(parent, padding=10)
        frm_top.pack(fill=X)
        tb.Button(frm_top, text="Ver Todos / Actualizar Tabla", command=self._refresh_goleadores, bootstyle=INFO).pack(side=LEFT, padx=5)

        self.tree_goleadores = tb.Treeview(parent, columns=("ranking", "nombre", "equipo", "goles"), show="headings", height=20)
        self.tree_goleadores.heading("ranking", text="Pos")
        self.tree_goleadores.heading("nombre", text="Jugador")
        self.tree_goleadores.heading("equipo", text="Equipo")
        self.tree_goleadores.heading("goles", text="Goles Totales")
        self.tree_goleadores.column("ranking", width=50, anchor="center")
        self.tree_goleadores.column("goles", width=100, anchor="center")
        self.tree_goleadores.pack(fill=BOTH, expand=True, padx=10, pady=10)
        self.tree_goleadores.bind("<Double-1>", self._on_editar_goles_totales_manual)

    def _ui_exportar(self, parent):
        # Eliminamos la creación local del tab y usamos el parent recibido
        frm_export = tb.Frame(parent, padding=30)
        frm_export.pack(anchor="n", pady=20)

        tb.Label(frm_export, text="Generador de Informes Profesionales", font="-size 14 -weight bold").grid(row=0, column=0, columnspan=2, pady=(0, 20))

        tb.Label(frm_export, text="Contenido a Exportar:").grid(row=1, column=0, padx=10, pady=10, sticky="w")
        self.combo_export_tipo = tb.Combobox(frm_export, state="readonly", width=30, values=["Tabla de Posiciones", "Lista de Goleadores"])
        self.combo_export_tipo.grid(row=1, column=1, padx=10, pady=10)
        self.combo_export_tipo.set("Tabla de Posiciones")

        tb.Label(frm_export, text="Formato de Destino:").grid(row=2, column=0, padx=10, pady=10, sticky="w")
        self.combo_export_formato = tb.Combobox(frm_export, state="readonly", width=30, values=["TXT", "CSV", "PDF"])
        self.combo_export_formato.grid(row=2, column=1, padx=10, pady=10)
        self.combo_export_formato.set("TXT")

        tb.Button(frm_export, text="💾 Generar y Guardar Archivo", command=self._on_exportar_archivo, bootstyle=SUCCESS).grid(row=3, column=0, columnspan=2, pady=30, sticky=EW)

    # =========================================================================
    # MÓDULO MUNDIAL 2026 - INTERFAZ Y LÓGICA UNIFICADA
    # =========================================================================

    def _ui_mundial(self, parent):
        import ttkbootstrap as tb
        from ttkbootstrap.constants import LEFT, RIGHT, BOTH, Y, X, W

        # AMPLIADO: Más ancho para que quepan las estadísticas del grupo
        frm_left = tb.Frame(parent, padding=10, width=480)
        frm_left.pack_propagate(False)
        frm_left.pack(side=LEFT, fill=Y)

        frm_right = tb.Frame(parent, padding=10)
        frm_right.pack(side=RIGHT, fill=BOTH, expand=True)

        # --- PANEL DE CONTROL ---
        frm_controles = tb.LabelFrame(frm_right, text=" Panel de Control y Resultados ")
        frm_controles.pack(fill=X, pady=(0, 15), ipadx=10, ipady=10)

        tb.Label(frm_controles, text="1. Seleccionar Enfrentamiento:", font="-weight bold").grid(row=0, column=0, sticky=W, padx=5, pady=5)
        self.combo_partido_mundial = tb.Combobox(frm_controles, width=50, state="readonly")
        self.combo_partido_mundial.grid(row=0, column=1, columnspan=3, sticky=W, padx=5, pady=5)
        self.combo_partido_mundial.bind("<<ComboboxSelected>>", self._actualizar_equipos_partido)

        tb.Button(frm_controles, text="⚙️ Editar Partido / Goles", command=self._abrir_editar_partido, bootstyle="warning-outline").grid(row=0, column=4, padx=15, pady=5)

        tb.Separator(frm_controles, orient="horizontal").grid(row=1, column=0, columnspan=5, sticky="ew", pady=10)

        tb.Label(frm_controles, text="2. Resultado Final:", font="-weight bold").grid(row=2, column=0, sticky=W, padx=5, pady=5)

        frm_goles_res = tb.Frame(frm_controles)
        frm_goles_res.grid(row=2, column=1, sticky=W, padx=5)
        tb.Label(frm_goles_res, text="Local / Visitante:").pack(side=LEFT)
        self.entry_mundial_gl = tb.Entry(frm_goles_res, width=8)
        self.entry_mundial_gl.pack(side=LEFT, padx=5)
        self.entry_mundial_gv = tb.Entry(frm_goles_res, width=8)
        self.entry_mundial_gv.pack(side=LEFT, padx=5)

        tb.Button(frm_controles, text="✅ Grabar Marcador", command=self._grabar_resultado_mundial, bootstyle=SUCCESS).grid(row=2, column=2, sticky=W, padx=10)

        tb.Separator(frm_controles, orient="horizontal").grid(row=3, column=0, columnspan=5, sticky="ew", pady=10)

        tb.Label(frm_controles, text="3. Asignar Goleadores:", font="-weight bold").grid(row=4, column=0, sticky=W, padx=5, pady=5)

        frm_goleadores = tb.Frame(frm_controles)
        frm_goleadores.grid(row=4, column=1, columnspan=3, sticky=W, padx=5)

        tb.Label(frm_goleadores, text="Equipo:").pack(side=LEFT)
        self.combo_equipo_mundial = tb.Combobox(frm_goleadores, width=15, state="readonly")
        self.combo_equipo_mundial.pack(side=LEFT, padx=5)
        self.combo_equipo_mundial.bind("<<ComboboxSelected>>", self._actualizar_jugadores_equipo)

        tb.Label(frm_goleadores, text="Jugador:").pack(side=LEFT, padx=(10, 5))
        self.combo_jugador_mundial = tb.Combobox(frm_goleadores, width=20, state="readonly")
        self.combo_jugador_mundial.pack(side=LEFT, padx=5)

        tb.Label(frm_goleadores, text="Goles:").pack(side=LEFT, padx=(10, 5))
        self.spin_goles_mundial = tb.Spinbox(frm_goleadores, from_=1, to=10, width=5)
        self.spin_goles_mundial.pack(side=LEFT, padx=5)
        self.spin_goles_mundial.set(1)

        tb.Button(frm_controles, text="⚽ Añadir Goleador", command=self._grabar_gol_mundial, bootstyle="info").grid(row=4, column=4, sticky=W, padx=15)

        # --- TABLA DE GRUPOS PROFESIONAL ---
        tb.Label(frm_left, text="Clasificación de Grupos", font="-size 11 -weight bold").pack(pady=(0, 5))
        self.tree_grupos = tb.Treeview(frm_left, columns=("grupo", "pais", "pj", "pg", "pe", "pp", "gf", "gc", "pts"), show="headings", height=10)
        self.tree_grupos.heading("grupo", text="Grp")
        self.tree_grupos.heading("pais", text="Selección")
        self.tree_grupos.heading("pj", text="PJ")
        self.tree_grupos.heading("pg", text="PG")
        self.tree_grupos.heading("pe", text="PE")
        self.tree_grupos.heading("pp", text="PP")
        self.tree_grupos.heading("gf", text="GF")
        self.tree_grupos.heading("gc", text="GC")
        self.tree_grupos.heading("pts", text="PTS")

        self.tree_grupos.column("grupo", width=30, anchor="center")
        self.tree_grupos.column("pais", width=110, anchor="w")
        self.tree_grupos.column("pj", width=30, anchor="center")
        self.tree_grupos.column("pg", width=30, anchor="center")
        self.tree_grupos.column("pe", width=30, anchor="center")
        self.tree_grupos.column("pp", width=30, anchor="center")
        self.tree_grupos.column("gf", width=30, anchor="center")
        self.tree_grupos.column("gc", width=30, anchor="center")
        self.tree_grupos.column("pts", width=35, anchor="center")
        self.tree_grupos.pack(fill=X, pady=(0, 15))

        tb.Label(frm_left, text="Máximos Goleadores (Mundial)", font="-size 11 -weight bold").pack(pady=(0, 5))
        self.tree_mundial_goleadores = tb.Treeview(frm_left, columns=("jugador", "goles"), show="headings", height=13)
        self.tree_mundial_goleadores.heading("jugador", text="Jugador")
        self.tree_mundial_goleadores.heading("goles", text="Goles")
        self.tree_mundial_goleadores.column("goles", width=50, anchor="center")
        self.tree_mundial_goleadores.pack(fill=BOTH, expand=True)

        # --- CALENDARIO ---
        tb.Label(frm_right, text="Calendario Oficial y Eliminatorias", font="-size 11 -weight bold").pack(pady=(0, 5))
        self.tree_mundial_partidos = tb.Treeview(frm_right, columns=("fecha", "partido", "resultado", "estadio", "fase"), show="headings", height=15)
        self.tree_mundial_partidos.heading("fecha", text="Fecha")
        self.tree_mundial_partidos.heading("partido", text="Enfrentamiento")
        self.tree_mundial_partidos.heading("resultado", text="Res.")
        self.tree_mundial_partidos.heading("estadio", text="Estadio")
        self.tree_mundial_partidos.heading("fase", text="Fase")
        self.tree_mundial_partidos.column("fecha", width=90, anchor="center")
        self.tree_mundial_partidos.column("resultado", width=60, anchor="center")
        self.tree_mundial_partidos.column("fase", width=110, anchor="center")
        self.tree_mundial_partidos.pack(fill=BOTH, expand=True)

        self.tree_mundial_partidos.bind("<Double-1>", self._seleccionar_partido_desde_tabla)
        self._cargar_datos_mundial()

    def _recalcular_grupos_mundial(self):
        import sqlite3

        try:
            conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
            cursor = conn.cursor()

            # Aseguramos que la tabla tenga las columnas necesarias
            columnas_nuevas = ["pj", "pg", "pe", "pp", "gf", "gc", "pts"]
            for col in columnas_nuevas:
                try:
                    cursor.execute(f"ALTER TABLE selecciones ADD COLUMN {col} INTEGER DEFAULT 0")
                except sqlite3.OperationalError:
                    pass

            # Resetear todo a 0
            cursor.execute("UPDATE selecciones SET pj=0, pg=0, pe=0, pp=0, gf=0, gc=0, pts=0")

            # Sumar puntos solo de la Fase de Grupos
            cursor.execute("""
                SELECT equipo_local_id, equipo_visitante_id, goles_local, goles_visitante 
                FROM partidos 
                WHERE goles_local IS NOT NULL AND goles_visitante IS NOT NULL AND fase = 'Fase de grupos'
            """)

            for l_id, v_id, gl, gv in cursor.fetchall():
                cursor.execute("UPDATE selecciones SET pj=pj+1, gf=gf+?, gc=gc+? WHERE id=?", (gl, gv, l_id))
                cursor.execute("UPDATE selecciones SET pj=pj+1, gf=gf+?, gc=gc+? WHERE id=?", (gv, gl, v_id))

                if gl > gv:
                    cursor.execute("UPDATE selecciones SET pg=pg+1, pts=pts+3 WHERE id=?", (l_id,))
                    cursor.execute("UPDATE selecciones SET pp=pp+1 WHERE id=?", (v_id,))
                elif gv > gl:
                    cursor.execute("UPDATE selecciones SET pp=pp+1 WHERE id=?", (l_id,))
                    cursor.execute("UPDATE selecciones SET pg=pg+1, pts=pts+3 WHERE id=?", (v_id,))
                else:
                    cursor.execute("UPDATE selecciones SET pe=pe+1, pts=pts+1 WHERE id=?", (l_id,))
                    cursor.execute("UPDATE selecciones SET pe=pe+1, pts=pts+1 WHERE id=?", (v_id,))

            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Error recalculando grupos: {e}")

    # --- LÓGICA DINÁMICA DE COMBOS ---
    def _seleccionar_partido_desde_tabla(self, event):
        item = self.tree_mundial_partidos.selection()
        if not item:
            return
        valores = self.tree_mundial_partidos.item(item, "values")
        if not valores:
            return

        enfrentamiento = valores[1]
        for idx, texto in enumerate(self.combo_partido_mundial["values"]):
            if enfrentamiento in texto:
                self.combo_partido_mundial.current(idx)
                self._actualizar_equipos_partido(None)
                break

    def _actualizar_equipos_partido(self, event=None):
        self.combo_equipo_mundial.set("")
        self.combo_jugador_mundial.set("")
        self.combo_jugador_mundial["values"] = ()

        seleccion = self.combo_partido_mundial.get()
        if not seleccion or " - " not in seleccion:
            return

        try:
            equipos_str = seleccion.split(" - ")[1]
            equipos = [e.strip() for e in equipos_str.split(" vs ")]
            if len(equipos) == 2:
                self.combo_equipo_mundial["values"] = equipos
        except Exception:
            pass

    def _actualizar_jugadores_equipo(self, event=None):
        equipo = self.combo_equipo_mundial.get()
        self.combo_jugador_mundial.set("")
        if not equipo:
            return

        import sqlite3

        try:
            conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
            cursor = conn.cursor()

            # DETECCIÓN INTELIGENTE DE COLUMNAS (Para evitar el error silencioso)
            cursor.execute("PRAGMA table_info(jugadores)")
            columnas = [col[1] for col in cursor.fetchall()]
            col_fk = "seleccion_id" if "seleccion_id" in columnas else "equipo_id"

            query = f"""
                SELECT j.nombre 
                FROM jugadores j
                JOIN selecciones s ON j.{col_fk} = s.id
                WHERE s.nombre = ?
                ORDER BY j.nombre ASC
            """
            cursor.execute(query, (equipo,))
            jugadores = [row[0] for row in cursor.fetchall()]

            self.combo_jugador_mundial["values"] = jugadores
            if jugadores:
                self.combo_jugador_mundial.current(0)
            conn.close()
        except Exception as e:
            print(f"Error extrayendo jugadores: {e}")

    # --- CARGA Y GRABACIÓN (Estricta y Aislada) ---
    def _cargar_datos_mundial(self):
        import sqlite3
        import tkinter as tk

        try:
            conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
            cursor = conn.cursor()

            try:
                cursor.execute("ALTER TABLE partidos ADD COLUMN goles_local INTEGER DEFAULT NULL")
                cursor.execute("ALTER TABLE partidos ADD COLUMN goles_visitante INTEGER DEFAULT NULL")
            except sqlite3.OperationalError:
                pass

            cursor.execute("""CREATE TABLE IF NOT EXISTS mundial_goleadores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                partido_id INTEGER,
                jugador_id INTEGER,
                goles INTEGER
            )""")
            conn.commit()

            # --- RECÁLCULO AUTOMÁTICO DE GRUPOS ---
            self._recalcular_grupos_mundial()

            self.combo_partido_mundial["values"] = ()
            cursor.execute("""
                SELECT p.id, el.nombre, ev.nombre 
                FROM partidos p
                JOIN selecciones el ON p.equipo_local_id = el.id
                JOIN selecciones ev ON p.equipo_visitante_id = ev.id
            """)
            self.combo_partido_mundial["values"] = [f"{r[0]} - {r[1]} vs {r[2]}" for r in cursor.fetchall()]

            # --- CARGA DE GRUPOS ESTADÍSTICOS ---
            self.tree_grupos.delete(*self.tree_grupos.get_children())
            cursor.execute("SELECT grupo, nombre, pj, pg, pe, pp, gf, gc, pts FROM selecciones ORDER BY grupo ASC, pts DESC, (gf-gc) DESC, gf DESC")
            for r in cursor.fetchall():
                self.tree_grupos.insert("", tk.END, values=r)

            self.tree_mundial_partidos.delete(*self.tree_mundial_partidos.get_children())
            cursor.execute("""
                SELECT p.fecha, el.nombre || ' vs ' || ev.nombre, 
                       IFNULL(p.goles_local, '-') || ' - ' || IFNULL(p.goles_visitante, '-'),
                       p.estadio, p.fase
                FROM partidos p
                JOIN selecciones el ON p.equipo_local_id = el.id
                JOIN selecciones ev ON p.equipo_visitante_id = ev.id
                ORDER BY p.fecha ASC
            """)
            for r in cursor.fetchall():
                self.tree_mundial_partidos.insert("", tk.END, values=r)

            self.tree_mundial_goleadores.delete(*self.tree_mundial_goleadores.get_children())
            cursor.execute("""
                SELECT j.nombre, SUM(mg.goles) as total
                FROM mundial_goleadores mg
                JOIN jugadores j ON mg.jugador_id = j.id
                GROUP BY j.id
                ORDER BY total DESC, j.nombre ASC
            """)
            for r in cursor.fetchall():
                self.tree_mundial_goleadores.insert("", tk.END, values=r)

            conn.close()
        except Exception as e:
            print(f"Error crítico DB: {e}")

    def _grabar_gol_mundial(self):
        import sqlite3
        import tkinter.messagebox as msg

        jugador = self.combo_jugador_mundial.get()
        equipo = self.combo_equipo_mundial.get()  # Extraemos el equipo para validar
        partido = self.combo_partido_mundial.get()
        try:
            goles = int(self.spin_goles_mundial.get())
        except ValueError:
            return

        if not jugador or not partido or not equipo:
            msg.showwarning("Atención", "Selecciona partido, equipo y jugador.")
            return

        try:
            id_partido = partido.split(" - ")[0]
            conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
            cursor = conn.cursor()

            # 1. Obtener ID del jugador y de su selección
            cursor.execute("PRAGMA table_info(jugadores)")
            columnas = [col[1] for col in cursor.fetchall()]
            col_fk = "seleccion_id" if "seleccion_id" in columnas else "equipo_id"

            cursor.execute(f"SELECT id, {col_fk} FROM jugadores WHERE nombre = ?", (jugador,))
            res_jugador = cursor.fetchone()
            if not res_jugador:
                msg.showerror("Error", "Jugador no encontrado.")
                conn.close()
                return

            id_jug, id_sel = res_jugador[0], res_jugador[1]

            # 2. VALIDADOR ESTRICTO: ¿Cuántos goles marcó este equipo en el partido?
            cursor.execute("SELECT equipo_local_id, equipo_visitante_id, goles_local, goles_visitante FROM partidos WHERE id = ?", (id_partido,))
            res_partido = cursor.fetchone()
            if not res_partido:
                conn.close()
                return

            l_id, v_id, gl, gv = res_partido

            if gl is None or gv is None:
                msg.showerror("Bloqueo de Seguridad", "Primero debes grabar el marcador numérico del partido antes de asignar goleadores.")
                conn.close()
                return

            es_local = id_sel == l_id
            goles_permitidos = gl if es_local else gv

            # 3. ¿Cuántos goles ya tiene asignados este equipo?
            cursor.execute(
                f"""
                SELECT SUM(mg.goles) FROM mundial_goleadores mg
                JOIN jugadores j ON mg.jugador_id = j.id
                WHERE mg.partido_id = ? AND j.{col_fk} = ?
            """,
                (id_partido, id_sel),
            )
            goles_ya_asignados = cursor.fetchone()[0] or 0

            # 4. Bloqueo si te pasas del límite
            if goles_ya_asignados + goles > goles_permitidos:
                restantes = goles_permitidos - goles_ya_asignados
                msg.showerror("Error de Cuadre", f"Límite excedido.\nLa selección de {equipo} marcó {goles_permitidos} gol(es) en total.\nYa has asignado {goles_ya_asignados} gol(es).\nSolo puedes asignar {restantes} gol(es) más.")
                conn.close()
                return

            # INSERTA EN LA TABLA
            cursor.execute("INSERT INTO mundial_goleadores (partido_id, jugador_id, goles) VALUES (?, ?, ?)", (id_partido, id_jug, goles))
            conn.commit()

            # Feedback inteligente
            goles_totales_ahora = goles_ya_asignados + goles
            faltan = goles_permitidos - goles_totales_ahora

            if faltan > 0:
                mensaje_exito = f"⚽ Añadido: {goles} gol(es) de {jugador}\n\n⚠️ ATENCIÓN: Aún falta por asignar {faltan} gol(es) a {equipo}."
            else:
                mensaje_exito = f"⚽ Añadido: {goles} gol(es) de {jugador}\n\n✅ ¡Goleadores de {equipo} cuadrados al 100%!"

            conn.close()

            self.spin_goles_mundial.set(1)
            self.combo_jugador_mundial.set("")  # Limpiamos la caja para no repetir por error
            self._cargar_datos_mundial()

            msg.showinfo("Éxito", mensaje_exito)

        except Exception as e:
            msg.showerror("Error DB", str(e))

    def _grabar_resultado_mundial(self):
        import sqlite3
        import tkinter.messagebox as msg

        partido = self.combo_partido_mundial.get()
        if not partido:
            msg.showwarning("Atención", "Selecciona un partido primero en el desplegable.")
            return

        gl_str = self.entry_mundial_gl.get().strip()
        gv_str = self.entry_mundial_gv.get().strip()

        if not gl_str and not gv_str:
            val_gl, val_gv = None, None
            mensaje = "El resultado ha sido borrado y la clasificación recalculada."
        else:
            try:
                val_gl = int(gl_str)
                val_gv = int(gv_str)
                if val_gl < 0 or val_gv < 0:
                    raise ValueError
                mensaje = "El marcador ha sido guardado."
            except ValueError:
                msg.showerror("Error", "El resultado debe estar en números, o dejar ambas cajas vacías para borrarlo.")
                return

        id_partido = partido.split(" - ")[0]

        try:
            conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
            cursor = conn.cursor()

            # --- VALIDADOR ESTRICTO DE RESULTADO ---
            if val_gl is not None and val_gv is not None:
                cursor.execute("SELECT equipo_local_id, equipo_visitante_id FROM partidos WHERE id = ?", (id_partido,))
                res_equipos = cursor.fetchone()
                if res_equipos:
                    l_id, v_id = res_equipos

                    # Comprobar goles locales ya asignados
                    cursor.execute(
                        """
                        SELECT SUM(mg.goles) FROM mundial_goleadores mg
                        JOIN jugadores j ON mg.jugador_id = j.id
                        WHERE mg.partido_id = ? AND j.seleccion_id = ?
                    """,
                        (id_partido, l_id),
                    )
                    asignados_loc = cursor.fetchone()[0] or 0

                    # Comprobar goles visitantes ya asignados
                    cursor.execute(
                        """
                        SELECT SUM(mg.goles) FROM mundial_goleadores mg
                        JOIN jugadores j ON mg.jugador_id = j.id
                        WHERE mg.partido_id = ? AND j.seleccion_id = ?
                    """,
                        (id_partido, v_id),
                    )
                    asignados_vis = cursor.fetchone()[0] or 0

                    # Evitar que bajen el marcador si ya hay goleadores asignados que lo superan
                    if asignados_loc > val_gl or asignados_vis > val_gv:
                        msg.showerror("Error de Cuadre", f"No puedes poner este resultado.\nYa hay {asignados_loc} goleadores locales y {asignados_vis} visitantes registrados.\nVe a 'Editar Partido' y limpia los goleadores primero.")
                        conn.close()
                        return

                    # Informar de lo que falta por rellenar
                    faltan_l = val_gl - asignados_loc
                    faltan_v = val_gv - asignados_vis
                    if faltan_l > 0 or faltan_v > 0:
                        mensaje += f"\n\nATENCIÓN: Tienes que asignar los goleadores.\nFaltan {faltan_l} goles del Local y {faltan_v} del Visitante."
                    else:
                        mensaje += "\n\n✅ Todo cuadra perfectamente. Goleadores completos."

            cursor.execute(
                """
                UPDATE partidos 
                SET goles_local = ?, goles_visitante = ?
                WHERE id = ?
            """,
                (val_gl, val_gv, id_partido),
            )
            conn.commit()
            conn.close()

            self._cargar_datos_mundial()

            self.entry_mundial_gl.delete(0, "end")
            self.entry_mundial_gv.delete(0, "end")

            msg.showinfo("Información de Marcador", mensaje)
        except Exception as e:
            msg.showerror("Error DB", str(e))

    # ===================================================================
    # LÓGICA DE INTERFACES Y ENLACE DE DATOS
    # ===================================================================

    def _refresh_all(self):
        self._refresh_comboboxes()
        self._refresh_equipos()
        self._refresh_jugadores()
        self._refresh_clasificacion()
        self._refresh_goleadores()
        self._refresh_partidos()

    def _refresh_comboboxes(self):
        equipos = self.db.obtener_nombres_equipos()
        self.combo_equipos_del.set_completion_list(equipos)
        self.combo_equipos_manual_pts.set_completion_list(equipos)
        self.combo_jugadores_equipo.set_completion_list(equipos)
        self.combo_partido_local.set_completion_list(equipos)
        self.combo_partido_visitante.set_completion_list(equipos)

        estado_archivados = 1 if self.mostrar_archivados_var.get() else 0
        jornadas = self.db.obtener_jornadas(estado_archivados)
        if estado_archivados:
            opciones = ["-- Archivo Histórico --"] + jornadas
            self.combo_filtra_jornadas.set_completion_list(opciones)
            self.combo_filtra_jornadas.set("-- Archivo Histórico --")
            self.btn_archivar_partido.config(text="♻️ Restaurar Partido")
        else:
            opciones = ["-- Ver Todos los Partidos --"] + jornadas
            self.combo_filtra_jornadas.set_completion_list(opciones)
            if not self.combo_filtra_jornadas.get() or self.combo_filtra_jornadas.get() == "-- Archivo Histórico --":
                self.combo_filtra_jornadas.set("-- Ver Todos los Partidos --")
            self.btn_archivar_partido.config(text="🗄️ Archivar Partido")

    def _refresh_equipos(self):
        pass

    def _refresh_jugadores(self):
        for item in self.tree_jugadores.get_children():
            self.tree_jugadores.delete(item)
        for j in self.db.obtener_jugadores_completo():
            self.tree_jugadores.insert("", tk.END, values=(j["id"], j["nombre"], j["equipo_nombre"], j["goles_marcados"]))

    def _refresh_clasificacion(self):
        for item in self.tree_clasificacion.get_children():
            self.tree_clasificacion.delete(item)

        datos_clas = self.db.obtener_clasificacion_actual()
        total_eq = len(datos_clas)

        for i, row in enumerate(datos_clas):
            pos = i + 1
            tag = ""
            leyenda = ""
            if pos == 1:
                tag, leyenda = ("campeon", "CAMPEÓN") if row["pj"] >= (total_eq - 1) * 2 and total_eq > 0 else ("lider", "LÍDER")
            elif 2 <= pos <= 4:
                tag, leyenda = "champions", "CHAMPIONS"
            elif 5 <= pos <= 6:
                tag, leyenda = "eurleague", "EURLEAGUE"
            elif pos == 7:
                tag, leyenda = "confleague", "CONFLEAGUE"
            elif total_eq >= 20 and pos >= total_eq - 2:
                tag, leyenda = "descenso", "DESCENSO"

            self.tree_clasificacion.insert("", tk.END, values=(pos, row["nombre"], row["pj"], row["pg"], row["pe"], row["pp"], row["gf"], row["gc"], row["pts"], leyenda), tags=(tag,))

    def _refresh_partidos(self):
        for item in self.tree_partidos.get_children():
            self.tree_partidos.delete(item)
        for item in self.tree_goleadores_partido.get_children():
            self.tree_goleadores_partido.delete(item)

        estado_archivados = 1 if self.mostrar_archivados_var.get() else 0
        filtro = self.combo_filtra_jornadas.get()

        partidos = self.db.obtener_partidos_con_equipos(filtro, estado_archivados)
        for p in partidos:
            marcador_l = p["goles_local"] if p["jugado"] else "Pendiente"
            marcador_v = p["goles_visitante"] if p["jugado"] else "Pendiente"
            self.tree_partidos.insert("", tk.END, iid=p["id"], values=(p["id"], p["nombre_equipo_local"], p["nombre_equipo_visitante"], marcador_l, marcador_v, p["fecha"]))

    def _refresh_goleadores(self):
        for item in self.tree_goleadores.get_children():
            self.tree_goleadores.delete(item)
        top = self.db.obtener_goleadores_top()
        for i, g in enumerate(top):
            self.tree_goleadores.insert("", tk.END, values=(i + 1, g["jugador"], g["equipo"], g["goles"]))

    def _on_aniadir_equipo(self):
        nombre = self.entry_equipo_nombre.get().strip()
        ciudad = self.entry_equipo_ciudad.get().strip()
        if nombre and ciudad:
            if self.db.agregar_equipo(nombre, ciudad):
                self.entry_equipo_nombre.delete(0, tk.END)
                self.entry_equipo_ciudad.delete(0, tk.END)
                self._refresh_all()
                messagebox.showinfo("Éxito", f"Equipo '{nombre}' registrado.")
            else:
                messagebox.showerror("Error", "El equipo ya existe.")
        else:
            messagebox.showwarning("Aviso", "Rellena los campos de nombre y ciudad.")

    def _on_eliminar_equipo(self):
        nombre = self.combo_equipos_del.get()
        if nombre:
            if messagebox.askyesno("Confirmar", f"¿Eliminar '{nombre}'? Se borrarán sus jugadores y partidos asociados."):
                self.db.eliminar_equipo_por_nombre(nombre)
                self.combo_equipos_del.set("")
                self.db.recalcular_y_obtener_clasificacion()
                self.db.recalcular_goleadores_totales()
                self._refresh_all()

    def _on_cargar_equipos_csv(self):
        ruta = filedialog.askopenfilename(title="Seleccionar CSV de Equipos", filetypes=[("CSV Files", "*.csv")])
        if ruta:
            try:
                with open(ruta, newline="", encoding="utf-8") as f:
                    reader = csv.reader(f)
                    for row in reader:
                        if row and len(row) >= 2:
                            self.db.agregar_equipo(row[0].strip(), row[1].strip())
                self._refresh_all()
                messagebox.showinfo("Éxito", "Equipos importados correctamente.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo leer el archivo: {e}")

    def _on_aniadir_jugador(self):
        nombre = self.entry_jugador_nombre.get().strip()
        equipo = self.combo_jugadores_equipo.get()
        if nombre and equipo:
            self.db.agregar_jugador(nombre, equipo)
            self.entry_jugador_nombre.delete(0, tk.END)
            self._refresh_all()
            messagebox.showinfo("Éxito", f"Jugador '{nombre}' añadido.")

    def _on_eliminar_jugador(self):
        nombre = self.entry_jugador_del.get().strip()
        if nombre:
            if messagebox.askyesno("Confirmar", f"¿Eliminar al jugador '{nombre}' de la liga?"):
                self.db.eliminar_jugador_por_nombre(nombre)
                self.entry_jugador_del.delete(0, tk.END)
                self.db.recalcular_goleadores_totales()
                self._refresh_all()

    def _on_cargar_jugadores_carpeta(self):
        ruta_dir = filedialog.askdirectory(title="Seleccionar Carpeta de Jugadores")
        if ruta_dir:
            try:
                contador = 0
                for archivo in os.listdir(ruta_dir):
                    if archivo.lower().endswith(".csv"):
                        equipo_nombre = os.path.splitext(archivo)[0].strip()
                        if self.db.obtener_id_equipo(equipo_nombre):
                            with open(os.path.join(ruta_dir, archivo), newline="", encoding="utf-8") as f:
                                reader = csv.reader(f)
                                for row in reader:
                                    if row and row[0].strip():
                                        self.db.agregar_jugador(row[0].strip(), equipo_nombre)
                                        contador += 1
                self._refresh_all()
                messagebox.showinfo("Éxito", f"Se cargaron {contador} jugadores desde la carpeta.")
            except Exception as e:
                messagebox.showerror("Error", f"Error procesando carpeta: {e}")

    def _on_crear_partido(self):
        local = self.combo_partido_local.get()
        visitante = self.combo_partido_visitante.get()
        fecha = self.entry_partido_fecha.get().strip()
        if local and visitante and fecha:
            if local == visitante:
                messagebox.showerror("Error", "Un equipo no puede jugar contra sí mismo.")
                return
            if self.db.agregar_partido(local, visitante, fecha):
                self.combo_partido_local.set("")
                self.combo_partido_visitante.set("")
                self._refresh_all()
                messagebox.showinfo("Éxito", "Partido programado.")
            else:
                messagebox.showerror("Error", "Verifica que los nombres de los equipos sean correctos.")

    def _on_cargar_jornada_csv(self):
        if messagebox.askyesno("Limpiar Pendientes", "¿Deseas eliminar partidos PENDIENTES antes de importar la nueva jornada?"):
            borrados = self.db.limpiar_partidos_pendientes()
            messagebox.showinfo("Limpieza", f"Se eliminaron {borrados} partidos pendientes antiguos.")

        ruta = filedialog.askopenfilename(title="Seleccionar CSV de Jornada", filetypes=[("CSV Files", "*.csv")])
        if ruta:
            try:
                importados = 0
                errores = []
                with open(ruta, newline="", encoding="utf-8") as f:
                    reader = csv.reader(f)
                    for i, row in enumerate(reader):
                        if len(row) >= 3:
                            local = row[0].strip()
                            visitante = row[1].strip()
                            fecha = row[2].strip()

                            # Si agregar_partido devuelve True, se sumó bien. Si es False, falta el equipo.
                            if self.db.agregar_partido(local, visitante, fecha):
                                importados += 1
                            else:
                                errores.append(f"Línea {i+1}: {local} vs {visitante}")

                self._refresh_all()

                # Gestión estricta de notificaciones
                if errores:
                    detalle = "\n".join(errores[:5])  # Mostrar los 5 primeros para no saturar la pantalla
                    if len(errores) > 5:
                        detalle += f"\n... y {len(errores)-5} más."

                    messagebox.showwarning(
                        "Importación Incompleta",
                        f"Se importaron {importados} partidos.\n\n" f"No se pudieron importar los siguientes (¿Faltan los equipos en la BD?):\n{detalle}\n\n" "RECUERDA: Los equipos deben estar creados ANTES de importar sus partidos.",
                    )
                elif importados > 0:
                    messagebox.showinfo("Éxito", f"Se importaron {importados} partidos correctamente.")
                else:
                    messagebox.showwarning("Aviso", "No se importó ningún partido. Verifica que el CSV no esté vacío y que los equipos existan.")

            except Exception as e:
                messagebox.showerror("Error", f"No se pudo procesar la jornada: {e}")

    def _on_registrar_resultado(self):
        partido_id = self.tree_partidos.focus()
        if not partido_id:
            messagebox.showwarning("Aviso", "Selecciona un partido en la lista de la derecha.")
            return
        partido_info = self.tree_partidos.item(partido_id)["values"]
        local_name, visitante_name = partido_info[1], partido_info[2]
        try:
            g_l = int(self.entry_goles_l.get())
            g_v = int(self.entry_goles_v.get())
            if g_l < 0 or g_v < 0:
                raise ValueError

            self.db.registrar_resultado_partido(partido_id, g_l, g_v)
            self.entry_goles_l.delete(0, tk.END)
            self.entry_goles_v.delete(0, tk.END)

            ventana_gol = VentanaGoleadores(self, partido_id, local_name, visitante_name, g_l, g_v, self.db)
            self.wait_window(ventana_gol)

            self.db.recalcular_goleadores_totales()
            self.db.recalcular_y_obtener_clasificacion()
            self._refresh_all()
        except ValueError:
            messagebox.showerror("Error", "Introduce números enteros válidos y no negativos.")

    def _on_partido_doble_clic(self, event):
        partido_id = self.tree_partidos.focus()
        if not partido_id:
            return
        partido_info = self.tree_partidos.item(partido_id)["values"]
        _, local_name, visitante_name, g_l, g_v, _ = partido_info
        if g_l == "Pendiente" or g_v == "Pendiente":
            messagebox.showinfo("Aviso", "Asigna un resultado primero usando los cuadros de goles.")
            return

        ventana_gol = VentanaGoleadores(self, partido_id, local_name, visitante_name, g_l, g_v, self.db)
        self.wait_window(ventana_gol)
        self.db.recalcular_goleadores_totales()
        self.db.recalcular_y_obtener_clasificacion()
        self._refresh_all()

    def _on_partido_seleccionado_ver_goleadores(self, event=None):
        for item in self.tree_goleadores_partido.get_children():
            self.tree_goleadores_partido.delete(item)
        partido_id = self.tree_partidos.focus()
        if partido_id:
            goleadores = self.db.obtener_goleadores_por_partido(partido_id)
            for g in goleadores:
                self.tree_goleadores_partido.insert("", tk.END, values=(g["jugador"], g["goles"]))

    def _on_toggle_archivo_partido(self):
        partido_id = self.tree_partidos.focus()
        if partido_id:
            estado_actual = 1 if self.mostrar_archivados_var.get() else 0
            nuevo_estado = 0 if estado_actual == 1 else 1
            self.db.toggle_archivo_partido(partido_id, nuevo_estado)
            self._refresh_all()
            messagebox.showinfo("Éxito", "Estado de archivo modificado.")

    def _on_eliminar_partido(self):
        partido_id = self.tree_partidos.focus()
        if partido_id:
            if messagebox.askyesno("Confirmar", "¿Eliminar definitivamente este partido?"):
                self.db.eliminar_partido_por_id(partido_id)
                self.db.recalcular_goleadores_totales()
                self.db.recalcular_y_obtener_clasificacion()
                self._refresh_all()

    def _on_jornada_filtrada(self, event=None):
        self._refresh_partidos()

    def _on_guardar_clasificacion_manual(self):
        equipo = self.combo_equipos_manual_pts.get()
        if not equipo:
            return
        try:
            pj = int(self.entry_m_pj.get())
            pg = int(self.entry_m_pg.get())
            pts = int(self.entry_m_pts.get())
            self.db.actualizar_clasificacion_manual(equipo, pj, pg, 0, 0, 0, 0, pts)
            self._refresh_clasificacion()
            messagebox.showinfo("Éxito", "Modificación manual de puntos guardada.")
        except ValueError:
            messagebox.showerror("Error", "Escribe valores numéricos enteros.")

    def _on_recalcular_clasificacion(self):
        if messagebox.askyesno("Confirmar", "Esto recalculará la tabla basándose exclusivamente en partidos grabados, anulando ajustes manuales. ¿Continuar?"):
            self.db.recalcular_y_obtener_clasificacion()
            self._refresh_clasificacion()

    def _on_editar_goles_totales_manual(self, event):
        item_id = self.tree_goleadores.focus()
        if not item_id:
            return
        valores = self.tree_goleadores.item(item_id)["values"]
        nombre_jugador = valores[1]
        goles_actuales = int(valores[3])

        nuevo_total = simpledialog.askinteger("Ajuste Manual", f"Goles totales de {nombre_jugador}:", initialvalue=goles_actuales, minvalue=0, parent=self)
        if nuevo_total is not None and nuevo_total != goles_actuales:
            if self.db.establecer_goles_totales_manual(nombre_jugador, nuevo_total):
                self._refresh_goleadores()
                self._refresh_jugadores()

    def importar_goleadores_sustituyendo(self):
        ruta = "goleadores_liga.txt"
        if not os.path.exists(ruta):
            ruta = filedialog.askopenfilename(title="Seleccionar archivo de Goleadores TXT", filetypes=[("Text Files", "*.txt")])
            if not ruta:
                return

        if messagebox.askyesno("Confirmar", "Esto modificará los goles de los jugadores según el archivo de texto. ¿Continuar?"):
            try:
                with open(ruta, "r", encoding="utf-8") as f:
                    lineas = f.readlines()
                    for linea in lineas[1:]:
                        partes = linea.strip().split("\t")
                        if len(partes) >= 4:
                            nombre_txt = partes[-4].strip()
                            goles_txt = int(partes[-1].strip())
                            self.db.establecer_goles_totales_manual(nombre_txt, goles_txt)
                self._refresh_goleadores()
                self._refresh_jugadores()
                messagebox.showinfo("Éxito", "Goles sincronizados desde el archivo de texto.")
            except Exception as e:
                messagebox.showerror("Error", f"Error al procesar el archivo: {e}")

    def _on_simulacro_historial(self):
        try:
            fecha_str = datetime.now().strftime("%Y_%m_%d_%H%M")
            nombre_archivo = f"SIMULACRO_Historial_Liga_{fecha_str}.txt"
            with open(nombre_archivo, "w", encoding="utf-8") as f:
                f.write("=== RESUMEN SIMULACRO LIGA ===\n\n")
                f.write("--- CLASIFICACIÓN ---\n")
                for r in self.db.obtener_clasificacion_actual():
                    f.write(f"{r['nombre']}: {r['pts']} Pts ({r['pj']} PJ)\n")
            messagebox.showinfo("Simulacro", f"Simulacro guardado correctamente en {nombre_archivo}. No se han borrado datos.")
        except Exception as e:
            messagebox.showerror("Error", f"Fallo en simulacro: {e}")

    def _on_nueva_temporada(self):
        if messagebox.askyesno("⚠️ RESET TOTAL", "ATENCIÓN: Se creará un informe histórico de cierre y se borrarán TODOS los datos de las tablas para iniciar una nueva temporada. ¿Estás absolutamente seguro?"):
            try:
                fecha_str = datetime.now().strftime("%Y_%m_%d_%H%M")
                nombre_archivo = f"Historial_Cierre_Liga_{fecha_str}.txt"
                with open(nombre_archivo, "w", encoding="utf-8") as f:
                    f.write("=== CIERRE DE TEMPORADA HISTÓRICO ===\n\n")
                    for r in self.db.obtener_clasificacion_actual():
                        f.write(f"{r['nombre']} - Puntos: {r['pts']}\n")

                self.db.cursor.execute("DELETE FROM goleadores_partido")
                self.db.cursor.execute("DELETE FROM partidos")
                self.db.cursor.execute("DELETE FROM jugadores")
                self.db.cursor.execute("DELETE FROM equipos")
                self.db.conn.commit()
                self._refresh_all()
                messagebox.showinfo("Éxito", f"Temporada archivada en '{nombre_archivo}'. Tablas limpias para nueva campaña.")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo completar el reset: {e}")

    def _on_exportar_archivo(self):
        tipo = self.combo_export_tipo.get()
        formato = self.combo_export_formato.get()

        cabeceras = []
        filas = []
        nombre_sug = "export"

        if tipo == "Tabla de Posiciones":
            cabeceras = ["Pos", "Equipo", "PJ", "PG", "PE", "PP", "GF", "GC", "Pts"]
            nombre_sug = "tabla_posiciones"
            for i, r in enumerate(self.db.obtener_clasificacion_actual()):
                filas.append([i + 1, r["nombre"], r["pj"], r["pg"], r["pe"], r["pp"], r["gf"], r["gc"], r["pts"]])
        else:
            cabeceras = ["Pos", "Jugador", "Equipo", "Goles"]
            nombre_sug = "goleadores_ranking"
            for i, g in enumerate(self.db.obtener_goleadores_top()):
                filas.append([i + 1, g["jugador"], g["equipo"], g["goles"]])

        ext = f".{formato.lower()}"
        ruta = filedialog.asksaveasfilename(initialfile=f"{nombre_sug}{ext}", defaultextension=ext)
        if not ruta:
            return

        try:
            if formato == "TXT":
                with open(ruta, "w", encoding="utf-8") as f:
                    f.write(f"--- INFORMES: {tipo.upper()} ---\n\n")
                    f.write("\t".join(cabeceras) + "\n")
                    for r in filas:
                        f.write("\t".join(map(str, r)) + "\n")
            elif formato == "CSV":
                with open(ruta, "w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)
                    writer.writerow(cabeceras)
                    writer.writerows(filas)
            elif formato == "PDF":
                if not HAS_REPORTLAB:
                    messagebox.showerror("Error", "ReportLab no está instalado en este entorno Python.")
                    return
                doc = SimpleDocTemplate(ruta, pagesize=letter)
                story = []
                tabla_datos = [cabeceras] + [[str(item) for item in row] for row in filas]
                pdf_table = Table(tabla_datos)
                pdf_table.setStyle(
                    TableStyle(
                        [
                            ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                            ("GRID", (0, 0), (-1, -1), 1, colors.black),
                        ]
                    )
                )
                story.append(pdf_table)
                doc.build(story)

            messagebox.showinfo("Éxito", "Informe exportado con éxito.")
        except Exception as e:
            messagebox.showerror("Error", f"Error escribiendo archivo: {e}")

    def al_cerrar(self):
        if messagebox.askokcancel("Salir", "¿Estás seguro de que deseas salir?"):
            try:
                # Soltar bloqueo de archivo SQLite de forma limpia
                self.db.close_db()
                if HAS_SINCRONIZADOR:
                    print("Sincronizando archivos al cerrar...")
                    sincronizador.ejecutar_sincronizacion()
            except Exception as e:
                print(f"Aviso al sincronizar: {e}")
            self.destroy()

    def _cargar_partidos_en_combo(self):
        # Limpiamos el combo primero
        self.combo_partido_mundial["values"] = ()

        conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
        cursor = conn.cursor()

        # AQUÍ SÍ ES CORRECTO TENER LA QUERY PORQUE ESTÁ DENTRO DE LA FUNCIÓN
        query = """
            SELECT p.id, el.nombre, ev.nombre 
            FROM partidos p
            JOIN selecciones el ON p.equipo_local_id = el.id
            JOIN selecciones ev ON p.equipo_visitante_id = ev.id
        """
        cursor.execute(query)
        partidos = [f"{row[0]} - {row[1]} vs {row[2]}" for row in cursor.fetchall()]

        self.combo_partido_mundial["values"] = partidos
        conn.close()

    def _abrir_editar_partido(self):
        seleccion = self.combo_partido_mundial.get()
        import tkinter.messagebox as msg
        import ttkbootstrap as tb
        import sqlite3

        if not seleccion:
            msg.showwarning("Atención", "Selecciona un partido primero.")
            return

        id_partido = seleccion.split(" - ")[0]

        try:
            conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT p.fecha, p.estadio, p.fase, el.nombre, ev.nombre, p.goles_local, p.goles_visitante
                FROM partidos p
                JOIN selecciones el ON p.equipo_local_id = el.id
                JOIN selecciones ev ON p.equipo_visitante_id = ev.id
                WHERE p.id = ?
            """,
                (id_partido,),
            )
            partido_info = cursor.fetchone()

            cursor.execute("SELECT id, nombre FROM selecciones ORDER BY nombre ASC")
            lista_selecciones = cursor.fetchall()
            conn.close()
        except Exception as e:
            msg.showerror("Error", f"No se pudo leer: {e}")
            return

        if not partido_info:
            return
        fecha_act, estadio_act, fase_act, nom_loc_act, nom_vis_act, gl_act, gv_act = partido_info

        dicc_selecciones = {nombre: id_sel for id_sel, nombre in lista_selecciones}
        nombres_paises = list(dicc_selecciones.keys())

        ventana_edit = tb.Toplevel(self)
        ventana_edit.title(f"Edición Total - Partido ID: {id_partido}")
        ventana_edit.geometry("450x550")
        ventana_edit.resizable(False, False)
        ventana_edit.grab_set()

        tb.Label(ventana_edit, text="Reconfigurar Datos del Partido", font="-size 13 -weight bold").pack(pady=10)

        tb.Label(ventana_edit, text="Equipo Local:").pack(pady=2)
        combo_local = tb.Combobox(ventana_edit, values=nombres_paises, state="readonly", width=35)
        combo_local.pack()
        combo_local.set(nom_loc_act)

        tb.Label(ventana_edit, text="Equipo Visitante:").pack(pady=2)
        combo_vis = tb.Combobox(ventana_edit, values=nombres_paises, state="readonly", width=35)
        combo_vis.pack()
        combo_vis.set(nom_vis_act)

        # --- AQUÍ ESTÁN LAS CAJAS DE GOLES QUE FALTABAN EN TU CAPTURA ---
        tb.Label(ventana_edit, text="Marcador (Local - Visitante):", font="-weight bold").pack(pady=(10, 2))
        frm_marc = tb.Frame(ventana_edit)
        frm_marc.pack()
        ent_gl = tb.Entry(frm_marc, width=5)
        ent_gl.pack(side="left", padx=2)
        if gl_act is not None:
            ent_gl.insert(0, str(gl_act))

        tb.Label(frm_marc, text="-").pack(side="left")

        ent_gv = tb.Entry(frm_marc, width=5)
        ent_gv.pack(side="left", padx=2)
        if gv_act is not None:
            ent_gv.insert(0, str(gv_act))

        tb.Label(ventana_edit, text="Fecha:").pack(pady=(10, 2))
        ent_fecha = tb.Entry(ventana_edit, width=37)
        ent_fecha.pack()
        ent_fecha.insert(0, fecha_act if fecha_act else "")

        tb.Label(ventana_edit, text="Estadio:").pack(pady=2)
        ent_estadio = tb.Entry(ventana_edit, width=37)
        ent_estadio.pack()
        ent_estadio.insert(0, estadio_act if estadio_act else "")

        tb.Label(ventana_edit, text="Fase / Eliminatoria:").pack(pady=2)
        fases = ["Fase de grupos", "Octavos de final", "Cuartos de final", "Semifinal", "Tercer Puesto", "Final"]
        combo_fase = tb.Combobox(ventana_edit, values=fases, width=35)
        combo_fase.pack()
        combo_fase.insert(0, fase_act if fase_act else "Fase de grupos")

        def guardar_cambios_totales():
            nuevo_loc = combo_local.get()
            nuevo_vis = combo_vis.get()
            if nuevo_loc == nuevo_vis:
                msg.showwarning("Atención", "Los equipos no pueden ser iguales.")
                return

            gl_val = ent_gl.get().strip()
            gv_val = ent_gv.get().strip()

            # Si el usuario borra los números, se guarda como NULL para eliminar el resultado
            val_gl = int(gl_val) if gl_val else None
            val_gv = int(gv_val) if gv_val else None

            try:
                conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
                cursor = conn.cursor()
                cursor.execute(
                    """
                    UPDATE partidos 
                    SET equipo_local_id = ?, equipo_visitante_id = ?, fecha = ?, estadio = ?, fase = ?, goles_local = ?, goles_visitante = ?
                    WHERE id = ?
                """,
                    (dicc_selecciones[nuevo_loc], dicc_selecciones[nuevo_vis], ent_fecha.get(), ent_estadio.get(), combo_fase.get(), val_gl, val_gv, id_partido),
                )
                conn.commit()
                conn.close()
                self._cargar_datos_mundial()
                ventana_edit.destroy()
                msg.showinfo("Éxito", "Partido actualizado. Si has borrado el marcador, la clasificación se ha recalculado.")
            except Exception as e:
                msg.showerror("Error", str(e))

        def limpiar_goleadores():
            if msg.askyesno("Confirmar", "¿Borrar a TODOS los goleadores registrados en este partido para volver a meterlos limpios?"):
                try:
                    conn2 = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
                    conn2.cursor().execute("DELETE FROM mundial_goleadores WHERE partido_id = ?", (id_partido,))
                    conn2.commit()
                    conn2.close()
                    self._cargar_datos_mundial()
                    msg.showinfo("Limpio", "Goleadores del partido borrados.")
                except Exception as e:
                    msg.showerror("Error", str(e))

        tb.Button(ventana_edit, text="💾 Guardar Todos los Cambios", command=guardar_cambios_totales, bootstyle="success").pack(pady=15)
        tb.Button(ventana_edit, text="🗑️ Limpiar Goleadores de este Partido", command=limpiar_goleadores, bootstyle="danger-outline").pack(pady=5)

    # =========================================================================
    # SUB-MÓDULO: CUADRO DE ELIMINATORIAS DEL MUNDIAL
    # =========================================================================

    def _ui_mundial_eliminatorias(self, parent):
        import ttkbootstrap as tb
        from ttkbootstrap.constants import LEFT, RIGHT, BOTH, Y, X, W
        from datetime import datetime

        frm_left = tb.Frame(parent, padding=10, width=320)
        frm_left.pack_propagate(False)
        frm_left.pack(side=LEFT, fill=Y)

        frm_right = tb.Frame(parent, padding=10)
        frm_right.pack(side=RIGHT, fill=BOTH, expand=True)

        # --- PANEL IZQUIERDO ARRIBA: Clasificados ---
        tb.Label(frm_left, text="Selecciones Clasificadas (32)", font="-size 12 -weight bold").pack(pady=(0, 5), anchor=W)
        tb.Label(frm_left, text="(1º, 2º y los 8 mejores 3º)", font="-size 9").pack(pady=(0, 10), anchor=W)

        # Reducimos la altura a 10 para hacer hueco a los goleadores
        self.tree_clasificados = tb.Treeview(frm_left, columns=("grupo", "pos", "pais", "pts"), show="headings", height=10)
        self.tree_clasificados.heading("grupo", text="Grp")
        self.tree_clasificados.heading("pos", text="Pos")
        self.tree_clasificados.heading("pais", text="Selección")
        self.tree_clasificados.heading("pts", text="Pts")
        self.tree_clasificados.column("grupo", width=35, anchor="center")
        self.tree_clasificados.column("pos", width=35, anchor="center")
        self.tree_clasificados.column("pais", width=120, anchor="w")
        self.tree_clasificados.column("pts", width=40, anchor="center")
        self.tree_clasificados.pack(fill=X, expand=False)

        tb.Button(frm_left, text="🔄 Refrescar Clasificados", command=self._cargar_eliminatorias_mundial, bootstyle="info-outline").pack(fill=X, pady=10)

        # --- PANEL IZQUIERDO ABAJO: Goleadores (CLONADO) ---
        tb.Label(frm_left, text="Máximos Goleadores (Mundial)", font="-size 11 -weight bold").pack(pady=(10, 5))
        self.tree_elim_goleadores = tb.Treeview(frm_left, columns=("jugador", "goles"), show="headings", height=10)
        self.tree_elim_goleadores.heading("jugador", text="Jugador")
        self.tree_elim_goleadores.heading("goles", text="Goles")
        self.tree_elim_goleadores.column("goles", width=50, anchor="center")
        self.tree_elim_goleadores.pack(fill=BOTH, expand=True)

        # --- PANEL DERECHO: Programador de Cruces ---
        frm_cruces = tb.LabelFrame(frm_right, text=" Generador de Cruces Oficiales ")
        frm_cruces.pack(fill=X, pady=(0, 15))

        tb.Label(frm_cruces, text="Fase:").grid(row=0, column=0, padx=5, pady=5, sticky=W)

        fases_elim = ["Dieciseisavos de final", "Octavos de final", "Cuartos de final", "Semifinal", "Tercer Puesto", "Final"]
        self.combo_fase_elim = tb.Combobox(frm_cruces, values=fases_elim, state="readonly", width=22)
        self.combo_fase_elim.grid(row=0, column=1, padx=5, pady=5)
        self.combo_fase_elim.set("Dieciseisavos de final")

        tb.Label(frm_cruces, text="Local:").grid(row=0, column=2, padx=5, pady=5, sticky=W)
        self.combo_elim_local = tb.Combobox(frm_cruces, state="readonly", width=22)
        self.combo_elim_local.grid(row=0, column=3, padx=5, pady=5)

        tb.Label(frm_cruces, text="Visitante:").grid(row=0, column=4, padx=5, pady=5, sticky=W)
        self.combo_elim_vis = tb.Combobox(frm_cruces, state="readonly", width=22)
        self.combo_elim_vis.grid(row=0, column=5, padx=5, pady=5)

        tb.Label(frm_cruces, text="Fecha:").grid(row=1, column=0, padx=5, pady=5, sticky=W)
        self.entry_elim_fecha = tb.Entry(frm_cruces, width=15)
        self.entry_elim_fecha.grid(row=1, column=1, padx=5, pady=5)
        self.entry_elim_fecha.insert(0, datetime.now().strftime("%Y-%m-%d"))

        tb.Button(frm_cruces, text="⚔️ Generar Cruce de Torneo", command=self._crear_cruce_eliminatoria, bootstyle="success").grid(row=1, column=4, columnspan=2, sticky="ew", padx=5, pady=5)

        # --- PANEL DERECHO INFERIOR: Cuadro del Torneo ---
        tb.Label(frm_right, text="Cuadro del Torneo (Rondas Finales)", font="-size 12 -weight bold").pack(pady=(0, 5), anchor=W)
        self.tree_cuadro_elim = tb.Treeview(frm_right, columns=("fase", "fecha", "partido", "resultado"), show="headings", height=15)
        self.tree_cuadro_elim.heading("fase", text="Fase de Torneo")
        self.tree_cuadro_elim.heading("fecha", text="Fecha")
        self.tree_cuadro_elim.heading("partido", text="Enfrentamiento")
        self.tree_cuadro_elim.heading("resultado", text="Resultado")
        self.tree_cuadro_elim.column("fase", width=140, anchor="center")
        self.tree_cuadro_elim.column("fecha", width=90, anchor="center")
        self.tree_cuadro_elim.column("partido", width=250, anchor="center")
        self.tree_cuadro_elim.column("resultado", width=70, anchor="center")
        self.tree_cuadro_elim.pack(fill=BOTH, expand=True)

        # --- ETIQUETAS DE COLOR DE FASES ---
        self.tree_cuadro_elim.tag_configure("dieciseisavos", background="#98FB98")
        self.tree_cuadro_elim.tag_configure("octavos", background="#006400", foreground="white", font=("Segoe UI", 10, "bold"))
        self.tree_cuadro_elim.tag_configure("cuartos", background="#ADD8E6")
        self.tree_cuadro_elim.tag_configure("semifinales", background="#F5DEB3")
        self.tree_cuadro_elim.tag_configure("final", background="#DC143C", foreground="white", font=("Segoe UI", 10, "bold"))
        self.tree_cuadro_elim.tag_configure("campeon", background="#32CD32", foreground="black", font=("Comic Mono", 14, "bold"))

        self._cargar_eliminatorias_mundial()

    def _cargar_eliminatorias_mundial(self):
        import sqlite3
        import tkinter as tk

        try:
            conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
            cursor = conn.cursor()

            # 1. Cargar Clasificados (Aplicando matemática de 32 equipos)
            self.tree_clasificados.delete(*self.tree_clasificados.get_children())
            cursor.execute("""
                SELECT grupo, nombre, pts, gf, gc 
                FROM selecciones 
                ORDER BY grupo ASC, pts DESC, (gf-gc) DESC, gf DESC
            """)

            grupos_vistos = {}
            clasificados_directos = []
            terceros = []

            for r in cursor.fetchall():
                grp, pais, pts, gf, gc = r[0], r[1], r[2], r[3], r[4]
                if grp not in grupos_vistos:
                    grupos_vistos[grp] = 1
                else:
                    grupos_vistos[grp] += 1

                pos = grupos_vistos[grp]
                if pos <= 2:
                    clasificados_directos.append((grp, f"{pos}º", pais, pts))
                elif pos == 3:
                    terceros.append({"grupo": grp, "pos_texto": "3º", "pais": pais, "pts": pts, "dif": (gf - gc), "gf": gf})

            terceros_ordenados = sorted(terceros, key=lambda x: (x["pts"], x["dif"], x["gf"]), reverse=True)
            mejores_terceros = terceros_ordenados[:8]

            paises_nombres = [item[2] for item in clasificados_directos] + [item["pais"] for item in mejores_terceros]
            paises_nombres.sort()

            self.combo_elim_local["values"] = paises_nombres
            self.combo_elim_vis["values"] = paises_nombres

            for item in clasificados_directos:
                self.tree_clasificados.insert("", tk.END, values=(item[0], item[1], item[2], item[3]))
            for item in mejores_terceros:
                self.tree_clasificados.insert("", tk.END, values=(item["grupo"], item["pos_texto"], item["pais"], item["pts"]))

            # 2. Cargar Cuadro del Torneo con los colores de fase correspondientes
            self.tree_cuadro_elim.delete(*self.tree_cuadro_elim.get_children())
            cursor.execute("""
                SELECT p.fase, p.fecha, el.nombre || ' vs ' || ev.nombre, 
                       IFNULL(p.goles_local, '-') || ' - ' || IFNULL(p.goles_visitante, '-'),
                       p.goles_local, p.goles_visitante, el.nombre, ev.nombre
                FROM partidos p
                JOIN selecciones el ON p.equipo_local_id = el.id
                JOIN selecciones ev ON p.equipo_visitante_id = ev.id
                WHERE p.fase != 'Fase de grupos'
                ORDER BY 
                    CASE p.fase 
                        WHEN 'Dieciseisavos de final' THEN 0
                        WHEN 'Octavos de final' THEN 1 
                        WHEN 'Cuartos de final' THEN 2 
                        WHEN 'Semifinal' THEN 3 
                        WHEN 'Tercer Puesto' THEN 4
                        WHEN 'Final' THEN 5 
                        ELSE 6 
                    END, p.fecha ASC
            """)

            campeon_torneo = None
            for r in cursor.fetchall():
                fase_db, fecha, enfrentamiento, resultado_str, gl, gv, nom_local, nom_visitante = r

                etiqueta_color = ""
                if fase_db == "Dieciseisavos de final":
                    etiqueta_color = "dieciseisavos"
                elif fase_db == "Octavos de final":
                    etiqueta_color = "octavos"
                elif fase_db == "Cuartos de final":
                    etiqueta_color = "cuartos"
                elif fase_db == "Semifinal":
                    etiqueta_color = "semifinales"
                elif fase_db == "Final":
                    etiqueta_color = "final"
                    if gl is not None and gv is not None:
                        if gl > gv:
                            campeon_torneo = nom_local
                        elif gv > gl:
                            campeon_torneo = nom_visitante
                        else:
                            campeon_torneo = f"{nom_local} o {nom_visitante} (Penaltis)"

                self.tree_cuadro_elim.insert("", tk.END, values=(fase_db, fecha, enfrentamiento, resultado_str), tags=(etiqueta_color,))

            if campeon_torneo:
                self.tree_cuadro_elim.insert("", tk.END, values=("🏆 CAMPEÓN DEL MUNDO", "⭐⭐⭐", f"¡{campeon_torneo.upper()}!", "⭐⭐⭐"), tags=("campeon",))

            # 3. NOVEDAD: Cargar la misma lista de Goleadores en esta pestaña
            self.tree_elim_goleadores.delete(*self.tree_elim_goleadores.get_children())
            cursor.execute("""
                SELECT j.nombre, SUM(mg.goles) as total
                FROM mundial_goleadores mg
                JOIN jugadores j ON mg.jugador_id = j.id
                GROUP BY j.id
                ORDER BY total DESC, j.nombre ASC
            """)
            for r in cursor.fetchall():
                self.tree_elim_goleadores.insert("", tk.END, values=r)

            conn.close()
        except Exception as e:
            print(f"Error cargando eliminatorias: {e}")

    def _crear_cruce_eliminatoria(self):
        import sqlite3
        import tkinter.messagebox as msg

        fase = self.combo_fase_elim.get()
        local = self.combo_elim_local.get()
        visitante = self.combo_elim_vis.get()
        fecha = self.entry_elim_fecha.get()

        if not local or not visitante or not fecha:
            msg.showwarning("Atención", "Selecciona equipos y fecha para generar el cruce.")
            return
        if local == visitante:
            msg.showwarning("Atención", "El equipo local y visitante no pueden ser el mismo.")
            return

        try:
            conn = sqlite3.connect(r"D:\Manu\Documentos\FUTBOL\MUNDIAL_26\mundial_2026.db")
            cursor = conn.cursor()

            cursor.execute("SELECT id FROM selecciones WHERE nombre = ?", (local,))
            id_loc = cursor.fetchone()
            cursor.execute("SELECT id FROM selecciones WHERE nombre = ?", (visitante,))
            id_vis = cursor.fetchone()

            if not id_loc or not id_vis:
                msg.showerror("Error", "Base de datos desincronizada.")
                conn.close()
                return

            cursor.execute(
                """
                INSERT INTO partidos (equipo_local_id, equipo_visitante_id, fecha, estadio, fase) 
                VALUES (?, ?, ?, '', ?)
            """,
                (id_loc[0], id_vis[0], fecha, fase),
            )

            conn.commit()
            conn.close()

            # Refrescamos ambas interfaces para que el partido pase a estar disponible de inmediato
            self._cargar_eliminatorias_mundial()
            self._cargar_datos_mundial()

            msg.showinfo("Cruce Creado", f"El cruce de {fase} ({local} vs {visitante}) se ha generado. Puedes asignarle el marcador desde la pestaña principal.")

        except Exception as e:
            msg.showerror("Error DB", str(e))



if __name__ == "__main__":
    # ================================================================
    # FASE 2: LOBBY — Gestor Universal y Dinamico de Torneos
    # Una sola raiz Tk durante toda la sesion.
    # El lobby se muestra como Toplevel sobre la ventana principal oculta.
    # Al elegir la BD, se completa la inicializacion de AppLigaFutbol.
    # ================================================================

    _db_elegida = [None]

    # Crear la raiz Tk unica (AppLigaFutbol hereda de tb.Window = tk.Tk)
    _root = tb.Window.__new__(AppLigaFutbol)
    tb.Window.__init__(_root, themename="litera",
                       title="Gestor Premium de Torneos")
    _root.withdraw()

    def _abrir_lobby():
        lobby = tk.Toplevel(_root)
        lobby.title("Gestor Universal de Torneos")
        lobby.resizable(False, False)
        lobby.grab_set()
        lobby.focus_force()
        lobby.protocol("WM_DELETE_WINDOW", lobby.destroy)

        lobby.update_idletasks()
        sw, sh = lobby.winfo_screenwidth(), lobby.winfo_screenheight()
        lobby.geometry(f"500x300+{(sw-500)//2}+{(sh-300)//2}")

        # ---- Layout del lobby ----
        tb.Label(_root if False else lobby,
                 text="\u26bd  Gestor Premium de Torneos",
                 font="-size 16 -weight bold").pack(pady=(25, 5))
        tb.Label(lobby,
                 text="Selecciona o crea el torneo que quieres gestionar",
                 font="-size 10").pack(pady=(0, 20))

        card = tb.Frame(lobby, padding=10)
        card.pack(fill=X, padx=40)

        def _cargar():
            ruta = filedialog.askopenfilename(
                parent=lobby,
                title="Abrir base de datos de torneo",
                filetypes=[("Base de Datos SQLite", "*.db")]
            )
            if ruta:
                _db_elegida[0] = ruta
                lobby.destroy()

        def _crear():
            nombre = simpledialog.askstring(
                "Nuevo Torneo", "Nombre del torneo (sin espacios):", parent=lobby
            )
            if nombre:
                ruta = nombre.strip().replace(" ", "_") + ".db"
                tmp = GestorBaseDeDatos(ruta)
                tmp.close_db()
                _db_elegida[0] = ruta
                lobby.destroy()

        tb.Button(card, text="\U0001f4c2  Cargar Torneo Existente",
                  bootstyle="primary", width=32, command=_cargar).pack(pady=6)
        tb.Button(card, text="\u2728  Crear Torneo Nuevo",
                  bootstyle="success-outline", width=32, command=_crear).pack(pady=6)

        _root.wait_window(lobby)

    _abrir_lobby()

    if not _db_elegida[0]:
        _root.destroy()
        sys.exit()

    try:
        AppLigaFutbol.__init__(_root, db_path=_db_elegida[0])
        _root.mainloop()
    except Exception as e:
        err = traceback.format_exc()
        messagebox.showerror(
            "Error Critico",
            f"No se pudo cargar el torneo:\n{e}\n\n{err}",
            parent=_root
        )
        _root.destroy()


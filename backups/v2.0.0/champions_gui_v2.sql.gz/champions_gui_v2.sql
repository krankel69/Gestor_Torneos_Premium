BEGIN TRANSACTION;
CREATE TABLE clasificados (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    equipo_id   INTEGER REFERENCES equipos(id) ON DELETE CASCADE,
    fase        TEXT,
    resultado   TEXT    DEFAULT NULL
);
CREATE TABLE equipos (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre  TEXT    NOT NULL UNIQUE,
    ciudad  TEXT    DEFAULT '',
    grupo   TEXT    DEFAULT NULL,
    pj      INTEGER DEFAULT 0,
    pg      INTEGER DEFAULT 0,
    pe      INTEGER DEFAULT 0,
    pp      INTEGER DEFAULT 0,
    gf      INTEGER DEFAULT 0,
    gc      INTEGER DEFAULT 0,
    pts     INTEGER DEFAULT 0
, ranking_fifa INTEGER DEFAULT 999);
CREATE TABLE goleadores_partido (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    partido_id  INTEGER REFERENCES partidos(id)  ON DELETE CASCADE,
    jugador_id  INTEGER REFERENCES jugadores(id) ON DELETE CASCADE,
    goles       INTEGER DEFAULT 0
);
CREATE TABLE jugadores (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre          TEXT    NOT NULL,
    equipo_id       INTEGER REFERENCES equipos(id) ON DELETE CASCADE,
    goles_marcados  INTEGER DEFAULT 0
);
CREATE TABLE partidos (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    equipo_local_id     INTEGER REFERENCES equipos(id) ON DELETE CASCADE,
    equipo_visitante_id INTEGER REFERENCES equipos(id) ON DELETE CASCADE,
    goles_local         INTEGER DEFAULT -1,
    goles_visitante     INTEGER DEFAULT -1,
    penaltis_local      INTEGER DEFAULT -1,
    penaltis_visitante  INTEGER DEFAULT -1,
    fecha               TEXT    DEFAULT '',
    estadio             TEXT    DEFAULT '',
    fase                TEXT    DEFAULT NULL,
    jornada             TEXT    DEFAULT NULL,
    jugado              INTEGER DEFAULT 0,
    archivado           INTEGER DEFAULT 0
, tarjetas_amarillas_local INTEGER DEFAULT 0, tarjetas_amarillas_visitante INTEGER DEFAULT 0, tarjetas_rojas_local INTEGER DEFAULT 0, tarjetas_rojas_visitante INTEGER DEFAULT 0, grupo TEXT DEFAULT NULL);
CREATE TABLE torneo_info (
    id          INTEGER PRIMARY KEY,
    nombre      TEXT    NOT NULL,
    tipo        TEXT    NOT NULL CHECK(tipo IN ('liga','copa','mundial','euro')),
    temporada   TEXT    DEFAULT ''
);
INSERT INTO "torneo_info" VALUES(1,'Champions Gui','copa','');
DELETE FROM "sqlite_sequence";
COMMIT;
